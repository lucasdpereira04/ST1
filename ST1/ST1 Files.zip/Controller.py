from Model import BoatModel

class BoatController:
    def __init__(self):
        self.model = BoatModel()

    def load_data(self, file_path):
        self.model.load_data(file_path)

    def clean_data(self):
        self.model.clean_data()

    def eda(self):
        self.model.eda()

    def handle_missing_values(self):
        self.model.handle_missing_values()

    def feature_selection(self):
        self.model.feature_selection()

    def convert_to_numeric(self):
        self.model.convert_to_numeric()

    def train_test_split(self):
        return self.model.train_test_split()

    def evaluate_models(self, X_train, X_test, y_train, y_test):
        return self.model.evaluate_models(X_train, X_test, y_train, y_test)

    def save_model(self, model_name):
        self.model.save_model(model_name)
